package tests;

import assignment1.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerTest {

    @Test
    void test_constructor_instantiates() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
    }

    @Test
    void test_getName_returnsInstanciationName() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        assertTrue(name.equals(jimBob.getName()));
    }

    @Test
    void test_getBalance_returnsInstanciationBalance0() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        assertEquals(balanceCents, jimBob.getBalance());
    }

    @Test
    void test_getBalance_returnsInstanciationBalance99999() {
        String name = "jim bob";
        int balanceCents = 99999;
        Customer jimBob = new Customer(name, balanceCents);
        assertEquals(balanceCents, jimBob.getBalance());
    }

    @Test
    void test_getBasket_instantiationBasketIsEmpty() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        Basket jimBobsBasket = jimBob.getBasket();
        assertEquals(0, jimBobsBasket.getNumOfReservations());
    }

    @Test
    void test_addFunds_add0Returns0() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        int fundsAddedCents = 0;
        jimBob.addFunds(fundsAddedCents);
        int expectedBalance = balanceCents + fundsAddedCents;
        assertEquals(expectedBalance, jimBob.addFunds(fundsAddedCents));
    }

    @Test
    void test_addFunds_start5000add8765Returns13765() {
        String name = "jim bob";
        int balanceCents = 5000;
        Customer jimBob = new Customer(name, balanceCents);
        int fundsAddedCents = 8765;
        int expectedBalance = balanceCents + fundsAddedCents;
        assertEquals(expectedBalance, jimBob.addFunds(fundsAddedCents));
    }

    @Test
    void test_addFunds_start5000add8765ChangesBalanceTo13765() {
        String name = "jim bob";
        int balanceCents = 5000;
        Customer jimBob = new Customer(name, balanceCents);
        int fundsAddedCents = 8765;
        int expectedBalance = balanceCents + fundsAddedCents;
        jimBob.addFunds(fundsAddedCents);
        assertEquals(expectedBalance, jimBob.getBalance());
    }

    @Test
    void test_addToBasketReservation_0ReservationsSizeIncreasedTo1() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        Basket jimBobsBasket = jimBob.getBasket();
        assertEquals(1, jimBobsBasket.getNumOfReservations());
    }

    @Test
    void test_addToBasketReservation_add4ReservationsSizeIncreasedTo4() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        Basket jimBobsBasket = jimBob.getBasket();
        assertEquals(4, jimBobsBasket.getNumOfReservations());
    }

    @Test
    void test_addToBasketReservation_0ReservationsAdd1Returns1() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        assertEquals(1, jimBob.addToBasket(hotelReservation));
    }

    @Test
    void test_addToBasketReservation_add3ReservationsReturns3() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        assertEquals(3, jimBob.addToBasket(hotelReservation));
    }

    @Test
    void test_addToBasketReservation_0ReservationsAdd1IsSameObject() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        Basket jimBobsBasket = jimBob.getBasket();
        assertTrue(jimBobsBasket.getProducts()[0] == hotelReservation);
    }

    @Test
    void test_addToBasketReservation_add4ReservationsLastIsSameObject() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(hotelReservation);
        Basket jimBobsBasket = jimBob.getBasket();
        int lastItemIndex = jimBobsBasket.getNumOfReservations() - 1;
        assertTrue(jimBobsBasket.getProducts()[lastItemIndex] == hotelReservation);
    }

    @Test
    void test_addToBasketReservation_addingIllegalReservationThrowsIllegalArgumentException() {
        String name = "not jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        assertThrows(IllegalArgumentException.class, () -> jimBob.addToBasket(getHotelReservation()));
    }

    @Test
    void test_addToBasketHotel_noBreakfastMakesHotelReservation() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);

        Hotel hotel = getHotelAllRoomTypes();
        String roomType = "double";
        int numberOfNights = 3;
        boolean breakfastIncluded = false;

        jimBob.addToBasket(hotel, roomType, numberOfNights, breakfastIncluded);
        Basket jimBobsBasket = jimBob.getBasket();
        assertTrue(jimBobsBasket.getProducts()[0] instanceof HotelReservation);
    }

    @Test
    void test_addToBasketHotel_breakfastMakesBnbReservation() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);

        Hotel hotel = getHotelAllRoomTypes();
        String roomType = "double";
        int numberOfNights = 3;
        boolean breakfastIncluded = true;

        jimBob.addToBasket(hotel, roomType, numberOfNights, breakfastIncluded);
        Basket jimBobsBasket = jimBob.getBasket();
        assertTrue(jimBobsBasket.getProducts()[0] instanceof BnBReservation);
    }

    @Test
    void test_addToBasketAirports_addsFlightReservation() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);

        Airport departureAirport = new Airport(0, 0, 53020);
        Airport arrivalAirport = new Airport(381, 989, 20000);

        jimBob.addToBasket(departureAirport, arrivalAirport);
        Basket jimBobsBasket = jimBob.getBasket();
        assertTrue(jimBobsBasket.getProducts()[0] instanceof FlightReservation);
    }

    @Test
    void test_addToBasketAirports_illegalAirportsStillReturnsNumberOfReservations() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);

        Airport departureAirport = new Airport(0, 0, 53020);
        assertEquals(0, jimBob.addToBasket(departureAirport, departureAirport));
    }

    @Test
    void test_removeFromBasket_successReturnsTrue() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        assertTrue(jimBob.removeFromBasket(hotelReservation));
    }

    @Test
    void test_removeFromBasket_failureReturnsFalse() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        assertFalse(jimBob.removeFromBasket(getHotelReservation()));
    }

    @Test
    void test_removeFromBasket_successReducesBasketSizeBy1() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        jimBob.removeFromBasket(hotelReservation);
        assertEquals(0, jimBob.getBasket().getNumOfReservations());
    }

    @Test
    void test_removeFromBasket_failureDoesNotChangeBasketSize() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        HotelReservation hotelReservation = getHotelReservation();
        jimBob.addToBasket(hotelReservation);
        jimBob.removeFromBasket(getHotelReservation());
        assertEquals(1, jimBob.getBasket().getNumOfReservations());
    }

    @Test
    void test_checkOut_failureInsuficientBalanceThrowsIllegalStateException() {
        String name = "jim bob";
        int balanceCents = 0;
        Customer jimBob = new Customer(name, balanceCents);
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        jimBob.addToBasket(getHotelReservation());
        assertThrows(IllegalStateException.class, jimBob::checkOut);
    }

    @Test
    void test_checkOut_successCorrectlyUpdatesBalance() {
        String name = "jim bob";
        int balanceCents = 100000;
        Customer jimBob = new Customer(name, balanceCents);
        jimBob.addToBasket(getHotelReservation());
        int expectedCostCents = balanceCents - jimBob.getBasket().getTotalCost();
        jimBob.checkOut();
        assertEquals(expectedCostCents, jimBob.getBalance());
    }

    @Test
    void test_checkOut_successClearsBasket() {
        String name = "jim bob";
        int balanceCents = 100000;
        Customer jimBob = new Customer(name, balanceCents);
        jimBob.addToBasket(getHotelReservation());
        jimBob.checkOut();
        assertEquals(0, jimBob.getBasket().getNumOfReservations());
    }

    @Test
    void test_checkOut_successReturnsCorrectBalanceLeft() {
        String name = "jim bob";
        int balanceCents = 100000;
        Customer jimBob = new Customer(name, balanceCents);
        jimBob.addToBasket(getHotelReservation());
        int expectedCostCents = balanceCents - jimBob.getBasket().getTotalCost();
        assertEquals(expectedCostCents, jimBob.checkOut());
    }

    private HotelReservation getHotelReservation(){
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelAllRoomTypes();
        String roomType = "double";
        int numberOfNights = 3;
        return new HotelReservation(reservationName, hotelAllRoomTypes, roomType, numberOfNights);
    }


    private Hotel getHotelAllRoomTypes(){
        Room room3 = new Room("double");
        Room room1 = new Room("queen");
        Room room2 = new Room("king");
        String hotelName = "hotelAllRoomTypes";

        Room[] myRooms = {room1, room2, room3};
        return new Hotel(hotelName, myRooms);
    }


}