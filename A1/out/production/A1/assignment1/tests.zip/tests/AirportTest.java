package tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import assignment1.Airport;

public class AirportTest {
    @Test
    public void test_getFees_feesShouldMatchInitialization(){
        int[] testFeesCents = {0, 1, 10, 384};
        for(int i = 0; i<testFeesCents.length; i++){
            int feesCents = testFeesCents[i];
            Airport myAirport = new Airport(0, 0, feesCents);
            assertEquals(feesCents, myAirport.getFees());
        }
    }

    @Test
    public void test_getDistance_distanceComputationShouldBeCorrect(){
        int x1 = 0;
        int x2 = 3;
        int y1 = 0;
        int y2 = 4;
        int answerDistance = 5;
        int sampleFees = 0;
        Airport myAirport1 = new Airport(x1, y1, sampleFees);
        Airport myAirport2 = new Airport(x2, y2, sampleFees);
        int distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance, distance);

        x1 = 27294;
        x2 = 54272;
        y1 = 543254;
        y2 = 9731853;
        answerDistance = 9188639;
        sampleFees = 0;
        myAirport1 = new Airport(x1, y1, sampleFees);
        myAirport2 = new Airport(x2, y2, sampleFees);
        distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance, distance);

        x1 = -247;
        x2 = 4372;
        y1 = 352;
        y2 = -17;
        answerDistance = 4634;
        sampleFees = 0;
        myAirport1 = new Airport(x1, y1, sampleFees);
        myAirport2 = new Airport(x2, y2, sampleFees);
        distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance, distance);
    }

    @Test
    public void test_getDistance_samePointZeroDistance(){
        int x1 = 0;
        int x2 = 0;
        int y1 = 0;
        int y2 = 0;
        int answerDistance1 = 0;
        int sampleFees = 0;
        Airport myAirport1 = new Airport(x1, y1, sampleFees);
        Airport myAirport2 = new Airport(x2, y2, sampleFees);
        int distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance1, distance);

        x1 = 923459;
        x2 = 923459;
        y1 = 23456345;
        y2 = 23456345;
        answerDistance1 = 0;
        sampleFees = 0;
        myAirport1 = new Airport(x1, y1, sampleFees);
        myAirport2 = new Airport(x2, y2, sampleFees);
        distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance1, distance);

        x1 = 923459;
        x2 = 923459;
        y1 = 23456345;
        y2 = 23456345;
        answerDistance1 = 0;
        sampleFees = 0;
        myAirport1 = new Airport(x1, y1, sampleFees);
        myAirport2 = new Airport(x2, y2, sampleFees);
        distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance1, distance);

        x1 = 2_147_483_647;
        x2 = 2_147_483_647;
        y1 = 2_147_483_647;
        y2 = 2_147_483_647;
        answerDistance1 = 0;
        sampleFees = 0;
        myAirport1 = new Airport(x1, y1, sampleFees);
        myAirport2 = new Airport(x2, y2, sampleFees);
        distance = Airport.getDistance(myAirport1, myAirport2);
        assertEquals(answerDistance1, distance);
    }

}
