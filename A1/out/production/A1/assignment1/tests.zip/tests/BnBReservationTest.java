package tests;

import assignment1.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BnBReservationTest {
    @Test
    public void test_BnBReservation_constructor_instantiates() {
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelAllRoomTypes();
        String roomType = "double";
        int numberOfNights = 3;
        HotelReservation myBnBreservation = new BnBReservation(reservationName, hotelAllRoomTypes, roomType, numberOfNights);
    }

    @Test
    public void test_BnBReservation_getCost_returnsCorrectCost() {
        String reservationName = "jim bob";
        Hotel hotelOneDoubleRoom = getHotelOneDoubleRoom();
        String roomType = "double"; //9000 cents per night
        int numberOfNights = 3;
        int hotelReservationCostCents = 27000;
        int bnbReservationCostsCents = hotelReservationCostCents + (1000 * numberOfNights);
        HotelReservation myBnbReservation = new BnBReservation(
                reservationName,
                hotelOneDoubleRoom,
                roomType,
                numberOfNights);
        assertEquals(bnbReservationCostsCents, myBnbReservation.getCost());
    }


    private Hotel getHotelOneDoubleRoom(){
        Room room1 = new Room("double");
        String hotelName = "hotelOneDoubleRoom";
        Room[] myRooms = {room1};
        return new Hotel(hotelName, myRooms);
    }

    private Hotel getHotelAllRoomTypes(){
        Room room3 = new Room("double");
        Room room1 = new Room("queen");
        Room room2 = new Room("king");
        String hotelName = "hotelAllRoomTypes";

        Room[] myRooms = {room1, room2, room3};
        return new Hotel(hotelName, myRooms);
    }
}