package tests;

import assignment1.FlightReservation;
import assignment1.Airport;
import assignment1.Hotel;
import assignment1.Room;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FlightReservationTest {
    @Test
    public void test_FlightReservation_constructor_instantiates() {
        String reservationName = "jim bob";
        Airport departureAirport = new Airport(0, 0, 0);
        Airport arrivalAirport = new Airport(0, 1, 0);
        FlightReservation myFlightReservation = new FlightReservation(reservationName, departureAirport, arrivalAirport);
    }

    @Test
    public void test_FlightReservation_constructor_throwsIllegalArgumentExceptionWhenSameAirport() {

        assertThrows(IllegalArgumentException.class, () ->
        {
            String reservationName = "jim bob";
            Airport departureAirport = new Airport(7236, 7236, 0);
            FlightReservation myFlightReservation = new FlightReservation(reservationName, departureAirport, departureAirport);
            });
    }

    @Test
    public void test_FlightReservation_getCost_ComputationIsCorrect() {
        /*
        costs are calculated as:
            Fuel costs + Airport fees + Extras

            Fuel costs = $1.24/gal, 167.52km/gal
            Extras = $53.75 always.
         */
        String reservationName = "jim bob";
        Airport departureAirport = new Airport(0, 0, 53020);
        Airport arrivalAirport = new Airport(381, 989, 20000);
        //distance travelled in km: 1060
        // fuelCostCents = 784.6227316
        // total cost = 784... + 53020 + 20000 + 5375 = 79179.6... = 79180
        int correctCostsCents = 79180;
        FlightReservation myFlightReservation = new FlightReservation(reservationName, departureAirport, arrivalAirport);
        assertEquals(correctCostsCents, myFlightReservation.getCost());
    }

    @Test
    public void test_FlightReservation_equals_differentNamesReturnsFalse() {
        String reservationName1 = "jim bob";
        String reservationName2 = "not jim bob";
        Airport departureAirport = new Airport(0, 0, 53020);
        Airport arrivalAirport = new Airport(381, 989, 20000);
        FlightReservation flightReservation1 = new FlightReservation(reservationName1, departureAirport, arrivalAirport);
        FlightReservation flightReservation2 = new FlightReservation(reservationName2, departureAirport, arrivalAirport);
        assertFalse(flightReservation1.equals(flightReservation2));
    }


    @Test
    public void test_FlightReservation_equals_differentArrivalAirportsReturnsFalse() {
        String reservationName = "jim bob";
        Airport departureAirport = new Airport(0, 0, 53020);
        Airport arrivalAirport1 = new Airport(381, 989, 20000);
        Airport arrivalAirport2 = new Airport(999, 111, 20000);
        FlightReservation flightReservation1 = new FlightReservation(reservationName, departureAirport, arrivalAirport1);
        FlightReservation flightReservation2 = new FlightReservation(reservationName, departureAirport, arrivalAirport2);
        assertFalse(flightReservation1.equals(flightReservation2));
    }

    @Test
    public void test_FlightReservation_equals_differentDepartureAirportsReturnsFalse() {
        String reservationName = "jim bob";
        Airport departureAirport1 = new Airport(0, 0, 53020);
        Airport departureAirport2 = new Airport(10, 20, 53020);
        Airport arrivalAirport = new Airport(381, 989, 20000);
        FlightReservation flightReservation1 = new FlightReservation(reservationName, departureAirport1, arrivalAirport);
        FlightReservation flightReservation2 = new FlightReservation(reservationName, departureAirport2, arrivalAirport);
        assertFalse(flightReservation1.equals(flightReservation2));
    }

    @Test
    public void test_FlightReservation_equals_sameAirportsSameObjectsReturnsTrue() {
        String reservationName = "jim bob";
        String reservationNameWeirdCase = "jIm BoB";
        Airport departureAirport = new Airport(0, 0, 53020);
        Airport arrivalAirport = new Airport(381, 989, 20000);
        FlightReservation flightReservation1 = new FlightReservation(reservationName, departureAirport, arrivalAirport);
        FlightReservation flightReservation2 = new FlightReservation(reservationNameWeirdCase, departureAirport, arrivalAirport);
        assertTrue(flightReservation1.equals(flightReservation2));
    }

}