package tests;

import assignment1.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class BasketTest {
    @Test
    public void test_Basket_constructor_instantiates() {
        Basket myBasket = new Basket();

    }

    @Test
    public void test_Basket_getNumOfReservations_0ItemsShouldReturn0() {
        Basket myBasket = new Basket();
        assertEquals(0, myBasket.getNumOfReservations()); // == because should be same object
    }

    @Test
    public void test_Basket_getNumOfReservations_4ItemsAddedShouldReturn4() {
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        assertEquals(4, myBasket.getNumOfReservations()); // == because should be same object
    }

    @Test
    public void test_Basket_getNumOfReservations_2ItemsAdded1ItemRemovedShouldReturn1() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        myBasket.add(myHotelReservation);
        myBasket.add(getHotelReservation());
        myBasket.remove(myHotelReservation);
        assertEquals(1, myBasket.getNumOfReservations()); // == because should be same object
    }

    @Test
    public void test_Basket_getProducts_noProductsReturnsEmptyReservationArray() {
        Basket myBasket = new Basket();
        Reservation[] myRes = myBasket.getProducts();
        assertEquals(0, myBasket.getNumOfReservations());
    }

    @Test
    public void test_Basket_getProducts_returnsShallowCopy() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        myBasket.add(myHotelReservation);
        Reservation[] myRes = myBasket.getProducts();
        HotelReservation maybeMyReservation = (HotelReservation) myRes[0];
        assertTrue(myHotelReservation == maybeMyReservation); // == because should be same object
    }

    @Test
    public void test_Basket_add_0ItemsAdd1Returns1() {
        Basket myBasket = new Basket();
        int numRes = myBasket.add(getHotelReservation());
        assertEquals(1, numRes);
    }

    @Test
    public void test_Basket_add_2ItemsAdd1ReturnsSameSizeAsReservationArrayLength() {
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        int numRes = myBasket.add(getHotelReservation());
        Reservation[] myRes = myBasket.getProducts();
        assertEquals(myBasket.getNumOfReservations(), numRes);
    }

    @Test
    public void test_Basket_add_3ItemsAdd1Returns4() {
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        int numRes = myBasket.add(getHotelReservation());
        Reservation[] myRes = myBasket.getProducts();
        assertEquals(4, numRes);
    }

    @Test
    public void test_Basket_add_appendsObjectToEndOfList() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(myHotelReservation);
        Reservation[] myRes = myBasket.getProducts();
        HotelReservation maybeMyReservation = (HotelReservation) myRes[myBasket.getNumOfReservations()-1];
        assertTrue(myHotelReservation == maybeMyReservation); // == because should be same object
    }

    @Test
    public void test_Basket_remove_removesUnwantedReservation() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        myBasket.add(getHotelReservation());
        myBasket.add(myHotelReservation);
        myBasket.remove(myHotelReservation);
        Reservation[] myRes = myBasket.getProducts();
        assertEquals(1, myBasket.getNumOfReservations());
    }

    @Test
    public void test_Basket_remove_removeNotFoundReturnsFalse() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        HotelReservation wrongHotelReservation = getHotelReservation();
        myBasket.add(getHotelReservation());
        myBasket.add(myHotelReservation);
        assertFalse(myBasket.remove(wrongHotelReservation));
    }

    @Test
    public void test_Basket_remove_removeNotFoundDoesntChangeReservationsSize() {
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        int expectedNumberOfReservations = myBasket.getNumOfReservations();
        int expectedReservationsSize = myBasket.getProducts().length;
        myBasket.remove(getHotelReservation());
        int actualNumberOfReservations = myBasket.getNumOfReservations();
        int actualReservationsSize = myBasket.getProducts().length;
        assertEquals(3, actualNumberOfReservations);
        assertEquals(expectedReservationsSize, actualReservationsSize);
        assertTrue(expectedNumberOfReservations == actualNumberOfReservations);
    }

    @Test
    public void test_Basket_remove_removeNotFoundDoesntChangeReservations() {
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        Reservation[] expectedReservations = myBasket.getProducts();
        myBasket.remove(getHotelReservation());
        Reservation[] maybeIntactReservations = myBasket.getProducts();
        assertTrue(checkReservationsAreShallowEquals(expectedReservations, maybeIntactReservations));
    }

    @Test
    public void test_Basket_remove_emptyBasketReturnsFalse() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        assertFalse(myBasket.remove(myHotelReservation));
    }

    @Test
    public void test_Basket_remove_removeLastreservationReturnsTrue() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        myBasket.add(getHotelReservation());
        myBasket.add(myHotelReservation);
        boolean result = myBasket.remove(myHotelReservation);
        assertTrue(result);
    }

    @Test
    public void test_Basket_remove_removeInexistingReservationReturnsFalse() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation = getHotelReservation();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        boolean result = myBasket.remove(myHotelReservation);
        assertFalse(result);
    }

    @Test
    public void test_Basket_remove_removeLeavesNoGap() {
        Basket myBasket = new Basket();
        HotelReservation myHotelReservation1 = getHotelReservation();
        HotelReservation myHotelReservation2 = getHotelReservation();
        HotelReservation myHotelReservation3 = getHotelReservation();
        myBasket.add(myHotelReservation1);
        myBasket.add(myHotelReservation2);
        myBasket.add(myHotelReservation3);
        myBasket.remove(myHotelReservation2);

        Reservation[] myProducts =  myBasket.getProducts();
        assertEquals(2, myProducts.length);
        assertTrue(myHotelReservation1 == myProducts[0]);
        assertTrue(myHotelReservation3 == myProducts[1]);
    }

    @Test
    public void test_Basket_clear_clearingMakesNumOfReservationsSize0() {
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.clear();
        assertEquals(0, myBasket.getNumOfReservations());
    }


    @Test
    public void test_Basket_clear_clearingRemovesAllReservations(){
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.clear();
        assertTrue(checkReservationsContainNoReservations(myBasket.getProducts()));
    }

    //note: if you expect your code not to change the size of the basket after clear(), you can remove this test.
    @Test
    public void test_Basket_clear_clearingRemovesReservationsFromMemory(){
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.clear();
        assertEquals(0, myBasket.getProducts().length);
    }

    @Test
    public void test_Basket_clear_clearingDoesNotMakeReservationANullPointer(){
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.clear();
        assertNotEquals(null, myBasket.getProducts());
    }

    @Test
    public void test_Basket_getTotalCost_emptyBasketReturns0(){
        Basket myBasket = new Basket();
        assertEquals(0, myBasket.getTotalCost());
    }

    @Test
    public void test_Basket_getTotalCost_4SameReservationReturns4TimesOneReservation(){
        Basket myBasket = new Basket();
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());
        myBasket.add(getHotelReservation());

        int expectedPriceCents = getHotelReservation().getCost() * 4;

        assertEquals(expectedPriceCents, myBasket.getTotalCost());
    }

    private HotelReservation getHotelReservation(){
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelAllRoomTypes();
        String roomType = "double";
        int numberOfNights = 3;
        return new HotelReservation(reservationName, hotelAllRoomTypes, roomType, numberOfNights);
    }


    private Hotel getHotelAllRoomTypes(){
        Room room3 = new Room("double");
        Room room1 = new Room("queen");
        Room room2 = new Room("king");
        String hotelName = "hotelAllRoomTypes";

        Room[] myRooms = {room1, room2, room3};
        return new Hotel(hotelName, myRooms);
    }

    private boolean checkReservationsAreShallowEquals(Reservation[] reservations1, Reservation[] reservations2){
        if(reservations1 == null || reservations2 == null){
            return false;
        }

        if(reservations1.length != reservations2.length){
            return false;
        }

        for(int i = 0; i<reservations1.length; i++){
            if(reservations1[i] != reservations2[i]){
                return false;
            }
        }
        return true;
    }

    private boolean checkReservationsContainNoReservations(Reservation[] reservations){
        if(reservations.length == 0) return true;
        for(int i = 0; i<reservations.length; i++){
            if(reservations[i] != null){
                return false;
            }
        }
        return true;
    }

}