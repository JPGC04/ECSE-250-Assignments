package tests;

import assignment1.Room;
import assignment1.Hotel;
import assignment1.HotelReservation;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HotelReservationTest {
    @Test
    public void test_HotelReservation_constructor_instantiates() {
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelAllRoomTypes();
        String roomType = "double";
        int numberOfNights = 3;
        HotelReservation myHotelReservation = new HotelReservation(reservationName, hotelAllRoomTypes, roomType, numberOfNights);
    }

    @Test
    public void test_HotelReservation_constructor_throwsIllegalArgumentExceptionWhenReservationFails() {
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelOneDoubleRoom();
        String wrongRoomType = "king";
        int numberOfNights = 3;
        assertThrows(IllegalArgumentException.class, () ->
        {
            HotelReservation myHotelReservation = new HotelReservation(
                    reservationName,
                    hotelAllRoomTypes,
                    wrongRoomType,
                    numberOfNights);
        });
    }


    @Test
    public void test_HotelReservation_constructor_reservesCorrectRoomWhenInstantiated() {
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelOneDoubleRoom();
        String roomType = "double";
        int numberOfNights = 3;

        HotelReservation myHotelReservation = new HotelReservation(
                reservationName,
                hotelAllRoomTypes,
                roomType,
                numberOfNights);
        // The hotel has two double rooms. If instantiating causes reservation, instantiating the second time will
        // throw an illegal argument exception.
        assertThrows(IllegalArgumentException.class, () ->
        {
            HotelReservation secondHotelReservation = new HotelReservation(
                    reservationName,
                    hotelAllRoomTypes,
                    roomType,
                    numberOfNights);
        });
    }

    @Test
    public void test_HotelReservation_getNumOfNights_returnsCorrectNumOfNights() {
        String reservationName = "jim bob";
        Hotel hotelAllRoomTypes = getHotelOneDoubleRoom();
        String roomType = "double";
        int numberOfNights = 3;
        HotelReservation myHotelReservation = new HotelReservation(
                reservationName,
                hotelAllRoomTypes,
                roomType,
                numberOfNights);
        assertEquals(numberOfNights, myHotelReservation.getNumOfNights());
    }

    @Test
    public void test_HotelReservation_getCost_returnsCorrectCost() {
        String reservationName = "jim bob";
        Hotel hotelOneDoubleRoom = getHotelOneDoubleRoom();
        String roomType = "double"; //9000 cents per night
        int numberOfNights = 3;
        int hotelReservationCostCents = 27000;
        HotelReservation myHotelReservation = new HotelReservation(
                reservationName,
                hotelOneDoubleRoom,
                roomType,
                numberOfNights);
        assertEquals(hotelReservationCostCents, myHotelReservation.getCost());
    }

    @Test
    public void test_HotelReservation_equals_sameHotelReservationReturnsTrue() {
        String reservationName1 = "jim bob";
        String reservationName2 = "jim bob";
        String roomType1 = "double";
        String roomType2 = "double";
        Hotel hotelTwoDoubleRooms = getHotelTwoDoubleRooms();
        int numberOfNights = 3;
        HotelReservation myHotelReservation1 = new HotelReservation(
                reservationName1,
                hotelTwoDoubleRooms,
                roomType1,
                numberOfNights);
        HotelReservation myHotelReservation2 = new HotelReservation(
                reservationName2,
                hotelTwoDoubleRooms,
                roomType2,
                numberOfNights);
        assertTrue(myHotelReservation1.equals(myHotelReservation2));
    }

    @Test
    public void test_HotelReservation_equals_differentTypesReturnsFalse() {
        String reservationName1 = "jim bob";
        String roomType1 = "double";
        Hotel hotelTwoDoubleRooms = getHotelTwoDoubleRooms();
        int numberOfNights = 3;
        HotelReservation myHotelReservation1 = new HotelReservation(
                reservationName1,
                hotelTwoDoubleRooms,
                roomType1,
                numberOfNights);
        assertFalse(myHotelReservation1.equals(new String[5]));
    }


    @Test
    public void test_HotelReservation_equals_differentNamesReturnsFalse() {
        String reservationName1 = "jim bob";
        String reservationName2 = "definitely not jim bob";
        String roomType1 = "double";
        String roomType2 = "double";
        Hotel hotelTwoDoubleRooms = getHotelTwoDoubleRooms();
        int numberOfNights = 3;
        HotelReservation myHotelReservation1 = new HotelReservation(
                reservationName1,
                hotelTwoDoubleRooms,
                roomType1,
                numberOfNights);
        HotelReservation myHotelReservation2 = new HotelReservation(
                reservationName2,
                hotelTwoDoubleRooms,
                roomType2,
                numberOfNights);
        assertFalse(myHotelReservation1.equals(myHotelReservation2));
    }

    @Test
    public void test_HotelReservation_equals_differentRoomTypesReturnsFalse() {
        String reservationName1 = "jim bob";
        String reservationName2 = "jim bob";
        String roomType1 = "double";
        String roomType2 = "king";
        Hotel hotelAllRoomTypes = getHotelAllRoomTypes();
        int numberOfNights = 3;
        HotelReservation myHotelReservation1 = new HotelReservation(
                reservationName1,
                hotelAllRoomTypes,
                roomType1,
                numberOfNights);
        HotelReservation myHotelReservation2 = new HotelReservation(
                reservationName2,
                hotelAllRoomTypes,
                roomType2,
                numberOfNights);
        assertFalse(myHotelReservation1.equals(myHotelReservation2));
    }

    @Test
    public void test_HotelReservation_equals_differentNumberOfNightsReturnsFalse() {
        String reservationName1 = "jim bob";
        String reservationName2 = "jim bob";
        String roomType1 = "double";
        String roomType2 = "double";
        Hotel hotelTwoDoubleRooms = getHotelTwoDoubleRooms();
        int numberOfNights1 = 3;
        int numberOfNights2 = 4;
        HotelReservation myHotelReservation1 = new HotelReservation(
                reservationName1,
                hotelTwoDoubleRooms,
                roomType1,
                numberOfNights1);
        HotelReservation myHotelReservation2 = new HotelReservation(
                reservationName2,
                hotelTwoDoubleRooms,
                roomType2,
                numberOfNights2);
        assertFalse(myHotelReservation1.equals(myHotelReservation2));
    }

    private Hotel getHotelTwoDoubleRooms(){
        Room room1 = new Room("double");
        Room room2 = new Room("double");
        String hotelName = "hotelTwoDoubleRooms";
        Room[] myRooms = {room1, room2};
        return new Hotel(hotelName, myRooms);
    }

    private Hotel getHotelOneDoubleRoom(){
        Room room1 = new Room("double");
        String hotelName = "hotelOneDoubleRoom";

        Room[] myRooms = {room1};
        return new Hotel(hotelName, myRooms);
    }

    private Hotel getHotelAllRoomTypes(){
        Room room3 = new Room("double");
        Room room1 = new Room("queen");
        Room room2 = new Room("king");
        String hotelName = "hotelAllRoomTypes";

        Room[] myRooms = {room1, room2, room3};
        return new Hotel(hotelName, myRooms);
    }

}