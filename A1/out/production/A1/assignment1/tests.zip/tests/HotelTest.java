package tests;

import assignment1.Room;
import assignment1.Hotel;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HotelTest {

    @Test
    public void test_Hotel_generateDeepRoomArray_diffObjects() {
        Room room1 = new Room("queen");
        Room room2 = new Room("king");
        Room[] myRooms = {room1, room2};

        Hotel myHotel = new Hotel("the ginger bread hotel", myRooms);
    }

    @Test
    public void test_Hotel_reserveRoom_findsFirstGoodRoomRightPrice() {
        Room room1 = new Room("queen");
        Room room2 = new Room("king");
        Room room3 = new Room("king");

        Room[] myRooms = {room1, room2, room3};
        Hotel myHotel = new Hotel("name", myRooms);

        assertEquals(15000, myHotel.reserveRoom("king"));
        assertEquals(11000, myHotel.reserveRoom("queen"));
        assertEquals(15000, myHotel.reserveRoom("king"));
    }

    @Test
    public void test_Hotel_reserveRoom_cantFindThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () ->
        {
            Room room1 = new Room("queen");
            Room room2 = new Room("king");
            Room room3 = new Room("king");

            Room[] myRooms = {room1, room2, room3};
            Hotel myHotel = new Hotel("name", myRooms);
            myHotel.reserveRoom("double");
        });
    }

    @Test
    public void test_Hotel_reserveRoom_changesAndChecksAvailability() {
        Room room1 = new Room("king");

        Room[] myRooms = {room1};
        Hotel myHotel = new Hotel("name", myRooms);
        myHotel.reserveRoom("king");
        assertThrows(IllegalArgumentException.class, () ->
                myHotel.reserveRoom("king"));
    }

    @Test
    public void test_Hotel_cancelRoom_returnsTrueWhenSuccess() {
        Room room1 = new Room("queen");

        Room[] myRooms = {room1};
        Hotel myHotel = new Hotel("name", myRooms);
        myHotel.reserveRoom("queen");
        assertTrue(myHotel.cancelRoom("queen"));
    }

    @Test
    public void test_Hotel_cancelRoom_returnsFalseWhenFails() {
        Room room1 = new Room("queen");
        Room[] myRooms = {room1};
        Hotel myHotel = new Hotel("name", myRooms);
        myHotel.reserveRoom("queen");
        assertFalse(myHotel.cancelRoom("double"));
    }

}