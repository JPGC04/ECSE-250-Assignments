package tests;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.platform.commons.util.ReflectionUtils.readFieldValue;

import assignment1.Room;
import org.junit.jupiter.api.Test;


class RoomTest {
    @Test
    public void test_Room_invalidTypeThrowsIllegalArgumentException(){
        assertThrows(IllegalArgumentException.class, () ->
                new Room("wrong type"));
    }

    @Test
    public void test_Room_validTypeDoesNotThrow(){
        Room myRoom = new Room("double");
        myRoom = new Room("DoUbLe");
        myRoom = new Room("QuEeN");
        myRoom = new Room("kInG");
        myRoom = new Room("KING");
    }

    @Test
    public void test_Room_typeMatchesInitialization(){
        Room myRoom = new Room("double");
        assertEquals("double", myRoom.getType());

        myRoom = new Room("dOuBlE");
        assertEquals("double", myRoom.getType());

        myRoom = new Room("qUeEn");
        assertEquals("queen", myRoom.getType());

        myRoom = new Room("KING");
        assertEquals("king", myRoom.getType());
    }


    @Test
    public void test_Room_priceMatchesType(){
        Room myRoom = new Room("double");
        assertEquals(90_00, myRoom.getPrice());

        myRoom = new Room("dOuBlE");
        assertEquals(90_00, myRoom.getPrice());

        myRoom = new Room("qUeEn");
        assertEquals(110_00, myRoom.getPrice());

        myRoom = new Room("KING");
        assertEquals(150_00, myRoom.getPrice());
    }

    @Test
    public void test_Room_isAvailableNewRoomIsTrue(){
        Room myRoom = new Room("double");
        boolean isAvailable = Boolean.parseBoolean(readFieldValue(Room.class, "isAvailable", myRoom).get().toString());
        assertEquals(true, isAvailable);
    }

    @Test
    public void test_Room_changeAvailabilityChangesAvailability(){
        Room myRoom = new Room("double");
        boolean isAvailable = Boolean.parseBoolean(readFieldValue(Room.class, "isAvailable", myRoom).get().toString());
        assertEquals(true, isAvailable);

        myRoom.changeAvailability();
        isAvailable = Boolean.parseBoolean(readFieldValue(Room.class, "isAvailable", myRoom).get().toString());
        assertEquals(false, isAvailable);

        myRoom.changeAvailability();
        isAvailable = Boolean.parseBoolean(readFieldValue(Room.class, "isAvailable", myRoom).get().toString());
        assertEquals(true, isAvailable);
    }

    @Test
    public void test_Room_equalsTrueForEquals(){
        Room room1 = new Room("double");
        Room room2 = new Room("DouBle");
        assertTrue(checkRoomsEquals(room1, room2));
    }

    @Test
    public void test_Room_equalsFalseForDiff(){
        Room room1 = new Room("double");
        Room room2 = new Room("KING");
        assertEquals(false, checkRoomsEquals(room1, room2));
    }

    @Test
    public void test_Room_fromRoomCopiesAllFieldsCorrectly(){
        Room room1 = new Room("double");
        Room room2 = new Room(room1);
        assertTrue(checkRoomsEquals(room1, room2));
    }

    @Test
    public void test_Room_fromRoomModifiedAssertFieldsAreIndependent(){
        Room room1 = new Room("double");
        Room room2 = new Room(room1);
        assertTrue(checkRoomsEquals(room1, room2));

        room2.changeAvailability();
        assertEquals(false, checkRoomsEquals(room1, room2));
    }


    @Test
    public void test_Room_fromRoomCopiesNotSameObject(){
        Room room1 = new Room("double");
        Room room2 = new Room(room1);
        assertTrue(room1 != room2);
    }


    @Test
    public void test_Room_findAvailableNoneAvailableReturnsNull(){
        Room[] rooms = {new Room("double"), new Room("king")};
        String desiredType = "queen";
        Room goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertEquals(null, goodRoom);

        rooms[1] = new Room("queen");
        desiredType = "king";
        goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertEquals(null, goodRoom);

        rooms[0] = new Room("king");
        desiredType = "double";
        goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertEquals(null, goodRoom);

        rooms = new Room[1];
        desiredType = "queen";
        goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertEquals(null, goodRoom);
    }


    @Test
    public void test_Room_findAvailableFindsAvailable(){
        String desiredType = "double";
        Room desiredRoom = new Room(desiredType);
        Room similarRoom = new Room(desiredType);
        assertTrue(desiredRoom != similarRoom); //!= checks different addresses

        Room[] rooms = {desiredRoom, new Room("queen"), new Room("king")};
        Room goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertTrue(desiredRoom == goodRoom); //== for same object, same address

        desiredType = "queen";
        desiredRoom = new Room(desiredType);
        rooms[1] = desiredRoom;
        goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertTrue(desiredRoom == goodRoom); //== for same object, same address

        desiredType = "king";
        desiredRoom = new Room(desiredType);
        rooms[2] = desiredRoom;
        goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertTrue(desiredRoom == goodRoom); //== for same object, same address

    }


    @Test
    public void test_Room_findAvailableFindsFirstAvailable(){
        String desiredType = "double";
        Room desiredRoom = new Room(desiredType);
        Room similarRoom = new Room(desiredType);
        assertTrue(desiredRoom != similarRoom); //!= checks different addresses

        Room[] rooms = {desiredRoom, new Room("queen"), similarRoom, new Room("king")};
        Room goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertTrue(desiredRoom == goodRoom); //== for same object, same address

        rooms[0] = similarRoom;
        goodRoom = Room.findAvailableRoom(rooms, desiredType);
        assertTrue(similarRoom == goodRoom);
    }

    @Test
    public void test_Room_makeRoomAvailable_returnsFalseWhenNoneAvailable(){
        String desiredType = "double";
        Room[] rooms = {new Room("queen"), new Room("king")};
        assertEquals(false, Room.makeRoomAvailable(rooms, desiredType));

        desiredType = "queen";
        Room unavailableKingRoom = new Room("king");
        unavailableKingRoom.changeAvailability();
        Room[] rooms2 = {new Room("double"), unavailableKingRoom};
        assertEquals(false, Room.makeRoomAvailable(rooms2, desiredType));

        desiredType = "king";
        Room[] rooms3 = {new Room("double"), new Room("queen"), new Room("king")};
        assertEquals(false, Room.makeRoomAvailable(rooms3, desiredType));

        rooms = new Room[5];
        assertEquals(false, Room.makeRoomAvailable(rooms, desiredType));
    }

    @Test
    public void test_Room_makeRoomAvailable_returnsTrueWhenSuccess(){
        String desiredType = "double";
        Room UnavailableDesiredRoom = new Room(desiredType);
        UnavailableDesiredRoom.changeAvailability();
        Room[] rooms = {new Room("queen"), new Room("queen"), UnavailableDesiredRoom, new Room("queen"), new Room("king")};
        assertEquals(true, Room.makeRoomAvailable(rooms, desiredType));
    }

    @Test
    public void test_Room_makeRoomAvailable_unavailableRoomShouldBeAvailable(){
        String desiredType = "double";
        Room UnavailableDesiredRoom = new Room(desiredType);
        UnavailableDesiredRoom.changeAvailability();

        boolean isAvailable = Boolean.parseBoolean(
                readFieldValue(Room.class, "isAvailable", UnavailableDesiredRoom).get().toString());
        assertEquals(false, isAvailable);

        Room[] rooms = {new Room("queen"), new Room("queen"), UnavailableDesiredRoom, new Room("queen"), new Room("king")};
        Room.makeRoomAvailable(rooms, desiredType);
        isAvailable = Boolean.parseBoolean(
                readFieldValue(Room.class, "isAvailable", UnavailableDesiredRoom).get().toString());
        assertEquals(true, isAvailable);
    }

    @Test
    public void test_Room_makeRoomAvailable_onlyFirstUnavailableRoomShouldBeAvailable(){
        String desiredType = "double";
        Room unavailableDesiredRoom = new Room(desiredType);
        Room secondUnavailableRoom = new Room(desiredType);
        unavailableDesiredRoom.changeAvailability();
        secondUnavailableRoom.changeAvailability();

        Room[] rooms = {new Room("queen"), unavailableDesiredRoom, secondUnavailableRoom, new Room("queen"), new Room("king")};
        Room.makeRoomAvailable(rooms, desiredType);
        boolean desiredIsAvailable = Boolean.parseBoolean(
                readFieldValue(Room.class, "isAvailable", unavailableDesiredRoom).get().toString());
        assertEquals(true, desiredIsAvailable);

        boolean undesiredIsAvailable = Boolean.parseBoolean(
                readFieldValue(Room.class, "isAvailable", secondUnavailableRoom).get().toString());
        assertEquals(false, undesiredIsAvailable);
    }


    private boolean checkRoomsEquals(Room room1, Room room2){
        boolean isAvailable1 = Boolean.parseBoolean(readFieldValue(Room.class, "isAvailable", room1).get().toString());
        boolean isAvailable2 = Boolean.parseBoolean(readFieldValue(Room.class, "isAvailable", room2).get().toString());

        if(isAvailable1 == isAvailable2
                && room1.getPrice() == room2.getPrice()
                && room1.getType().equals(room2.getType())){
            return(true);
        }
        else{
            return(false);
        }
    }

}